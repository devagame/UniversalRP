// UniversalRP Shaders folder need an Assembly Definition files to create a .cs project
// This is a dummy shader file so the Shaders assembly is not empty.
class ShadersDummy { }
