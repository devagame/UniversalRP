using UnityEngine.Rendering.Universal;


namespace UnityEditor.Rendering.Universal
{
    [CustomEditor(typeof(CompositeShadowCaster2D))]
    internal class CompositeShadowCaster2DEditor : Editor
    {
        public override void OnInspectorGUI()
        {
        }
    }
}
