namespace UnityEngine.Rendering.Universal
{
    public enum SampleCount
    {
        One = 1,
        Two = 2,
        Four = 4,
    }
}
