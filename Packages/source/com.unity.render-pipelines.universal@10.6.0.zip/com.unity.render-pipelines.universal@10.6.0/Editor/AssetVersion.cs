﻿using UnityEngine;

namespace UnityEditor.Rendering.Universal
{
    class AssetVersion : ScriptableObject
    {
        public int version;
    }
}
