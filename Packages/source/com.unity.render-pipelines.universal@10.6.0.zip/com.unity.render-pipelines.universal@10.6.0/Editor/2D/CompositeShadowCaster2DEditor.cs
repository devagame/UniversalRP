using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Experimental.Rendering.Universal;


namespace UnityEditor.Experimental.Rendering.Universal
{

    [CustomEditor(typeof(CompositeShadowCaster2D))]
    internal class CompositeShadowCaster2DEditor : Editor
    {
        public override void OnInspectorGUI()
        {
        }
    }
}
