# Customizing URP

This section contains information on how to customize and extend the rendering process in URP.

This section contains the following articles:

* [Using the beginCameraRendering event](using-begincamerarendering.md)
