[!include[](../renderer-features/how-to-custom-effect-render-objects.md)]
